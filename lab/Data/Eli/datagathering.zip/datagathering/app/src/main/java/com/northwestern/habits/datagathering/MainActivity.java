package com.northwestern.habits.datagathering;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.northwestern.habits.datagathering.banddata.BandDataService;

import java.io.File;

public class MainActivity extends AppCompatActivity {


    private final String TAG = "Main activity"; //For logs

    private boolean waitingToContinue = false;
    private Intent newStudyIntent;

    private Button newStudyButton;
    private Button editStudyButton;
    private Button endStudyButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        newStudyButton = (Button) findViewById(R.id.startStudyButton);
        editStudyButton = (Button) findViewById(R.id.manageStudyButton);
        endStudyButton = (Button) findViewById(R.id.endStudyButton);

        Log.v(TAG, "Creating database");
        mDbHelper = new DataStorageContract.BluetoothDbHelper(getApplicationContext());

        if (db == null) {
            Log.v(TAG, "the database is null");
        }

        storagePermitted(this);
    }

    private static boolean storagePermitted(Activity activity) {

        if (ActivityCompat.checkSelfPermission(activity, Manifest.permission.READ_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        == PackageManager.PERMISSION_GRANTED)

            return true;

        ActivityCompat.requestPermissions(activity, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE}, 0);

        return false;

    }

    @Override
    protected void onResume() {
        super.onResume();

        newStudyButton = (Button) findViewById(R.id.startStudyButton);
        editStudyButton = (Button) findViewById(R.id.manageStudyButton);
        endStudyButton = (Button) findViewById(R.id.endStudyButton);

        if (mDbHelper == null) {
            mDbHelper = new DataStorageContract.BluetoothDbHelper(getApplicationContext());
        }

    }



    /******************************* BUTTON HANDLERS *******************************/
    private final int REQUEST_ENABLE_BT = 1;

    public void startStudyClicked(View view) {
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setTitle("Please enter a unique study name \n(note: this will end the current study)");
        final EditText input = new EditText(this);
        b.setView(input);
        b.setPositiveButton("Enter", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int whichButton) {
                waitingToContinue = true;

                // Kill the old study
                endStudyClicked(endStudyButton);

                editStudyButton.setEnabled(true);
                endStudyButton.setEnabled(true);

                newStudyIntent = new Intent(
                        getApplicationContext(), DeviceManagementActivity.class);
                newStudyIntent.putExtra(DeviceManagementActivity.STUDY_NAME_EXTRA,
                        input.getText().toString());
                newStudyIntent.putExtra(DeviceManagementActivity.CONT_STUDY_EXTRA, false);
                startDevMgmtActivity();
            }
        });
        b.setNegativeButton("CANCEL", null);
        b.create().show();
    }

    public void manageStudyClicked(View view) {
        startDevMgmtActivity();
    }

    public void endStudyClicked(View view) {
        // TODO Add warning to confirm with user

        // Start Service with end study intent
        Intent endStudyIntent = new Intent(this,
                BandDataService.class);
        endStudyIntent.putExtra(DeviceManagementActivity.CONT_STUDY_EXTRA, false);
        startService(endStudyIntent);

        endStudyButton.setEnabled(false);
        editStudyButton.setEnabled(false);
    }


    private void startDevMgmtActivity() {
        if (btEnabled()) {
            locEnabled();
        }
    }




    private boolean btEnabled() {
        // Check for bluetooth connection
        BluetoothAdapter adapter = BluetoothConnectionLayer.getAdapter();
        if (adapter == null) {
            new AlertDialog.Builder(this)
                    .setTitle("No Bluetooth")
                    .setMessage("There is no bluetooth adapter for this device. To manage bluetooth" +
                            "device connections, please run this app on a device with bluetooth support.")
                    .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                        }
                    })
                    .setIcon(android.R.drawable.ic_dialog_alert)
                    .show();

            Log.v(TAG, "No adapter found");
        } else {
            Log.v(TAG, "About to check bluetooth enabled");
            if (!adapter.isEnabled()) {
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
            }

            Log.v(TAG, "About to check enabled again");
            if (adapter.isEnabled()) {
                return true;
            }
        }
        return false;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // Check which request we're responding to
        if (requestCode == REQUEST_ENABLE_BT) {
            // Make sure the request was successful
            if (resultCode == RESULT_OK) {
                // Recall startMgmtActivity
                startDevMgmtActivity();
            }
        }
    }


    private final int MY_PERMISSIONS_REQUEST_COARSE_LOCATION = 0;
    private void locEnabled( ) {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            // Coarse location permission not granted, request it
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, MY_PERMISSIONS_REQUEST_COARSE_LOCATION);
        } else {
            // Permission was previously granted
            onRequestPermissionsResult(MY_PERMISSIONS_REQUEST_COARSE_LOCATION,
                    new String[]{}, new int[]{PackageManager.PERMISSION_GRANTED});
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String permissions[], @NonNull int[] grantResults) {
        Log.v(TAG, "Got permission result");
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_COARSE_LOCATION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    if (waitingToContinue) {
                        newStudyIntent.putExtra(DeviceManagementActivity.BT_LE_EXTRA, true);
                    } else {
                        newStudyIntent = new Intent(
                                getApplicationContext(), DeviceManagementActivity.class);
                        newStudyIntent.putExtra(DeviceManagementActivity.CONT_STUDY_EXTRA, true);
                        newStudyIntent.putExtra(DeviceManagementActivity.BT_LE_EXTRA, true);
                    }
                    startActivity(newStudyIntent);

                } else {
                    // Start a device management activity without bluetooth le

                    Intent devManagementIntent = new Intent(
                            getApplicationContext(), DeviceManagementActivity.class);
                    devManagementIntent.putExtra(DeviceManagementActivity.CONT_STUDY_EXTRA, true);
                    devManagementIntent.putExtra(DeviceManagementActivity.BT_LE_EXTRA, false);
                    startActivity(devManagementIntent);

                }
            }
            // other 'case' lines to check for other
            // permissions this app might request
        }
    }


    /* ******************************** DATABASE TESTING ********************************* */
    public SQLiteDatabase db;
    DataStorageContract.BluetoothDbHelper mDbHelper;

    public void onDeleteDatabase( View view ) {
        db = mDbHelper.getWritableDatabase();


        mDbHelper.onUpgrade(db, db.getVersion(), db.getVersion() + 1);
    }

    public void onReadDatabase(View view) {
        db = mDbHelper.getWritableDatabase();
        Log.v(TAG, "Got database " + db);

        String studyId = "0";

        // Querry databse for the study name
        String[] projection = new String[] {
                DataStorageContract.StudyTable._ID,
                DataStorageContract.StudyTable.COLUMN_NAME_STUDY_ID
        };

        // Query for the specified studyId
        Cursor cursor = db.query(
                DataStorageContract.StudyTable.TABLE_NAME,
                projection,
                DataStorageContract.StudyTable.COLUMN_NAME_STUDY_ID + "=?",
                new String[] { studyId },
                null,
                null,
                null
        );
        cursor.moveToFirst();

        if (cursor.getCount() == 0)
            throw new Resources.NotFoundException();

        Log.v(TAG, "database path:" + db.getPath());

        File dattabsefile = new File(db.getPath());

        Intent i = new Intent(Intent.ACTION_SEND);
        i.putExtra(Intent.EXTRA_EMAIL, new String[] {"williamstogin2018@u.northwestern.edu"});
        i.putExtra(Intent.EXTRA_SUBJECT, "Database");
        i.putExtra(Intent.EXTRA_TEXT, "Attached is (hopefully) the database");
        i.setType("application/octet-stream");
        i.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(new File(db.getPath())));
        startActivity(Intent.createChooser(i, "Send e-mail"));
    }


    public void onSendDatabase (View view) {
        Log.v(TAG, "Send database clicked");
        // Stop streaming
        endStudyClicked(view);

        // Start sending to backend
        Intent intent = new Intent(this, ServerCommunicationService.class);
        startService(intent);
    }




}
